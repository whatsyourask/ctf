<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress_db' );

/** MySQL database username */
define( 'DB_USER', 'kb_vuln' );

/** MySQL database password */
define( 'DB_PASSWORD', 'hellelujah' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'aqE=MFhh0mWl*#QP)zeXRrbyiE&8y.OsSYWm0yrE:bLS._)=oJ3<wJ2mk<R.ku)j' );
define( 'SECURE_AUTH_KEY',  'PR%bu*>VrL.Al2tlX|Aq&k:W;P-G@/OJugE-];SACS{{_w_44@8)p3|)phi{v0pC' );
define( 'LOGGED_IN_KEY',    'x4e2q^}{a)%4W26.1)zB$cGRJJf<B@_kY4w&=LvDGr`Rs;T5(g4*OC<NOZC)Lhd%' );
define( 'NONCE_KEY',        '2RbBMxk# n 0~*BHmK32%ru?ilyT{qA1L3>+G_g;v:R4p~P0g~(?#qi2^=WuH?j>' );
define( 'AUTH_SALT',        '/:pgyeXqLq||4u8RR3B>[a&ghGbeKgw<vhRGwr+ZTJRAMz^T^2;H:z]wf6+Yv(cu' );
define( 'SECURE_AUTH_SALT', '3ujbmX9Tvg[y!z@uqI?&7rqJ,F.q8JH,X>BI=5g1wtKPo$1V[CDmcG/u^<2Jt,NR' );
define( 'LOGGED_IN_SALT',   'DAOZ;2F(G)@0UP>kAAG^#^r?F*wPTI%(.27^NeP+V=dIi,D?0hn@~:zL+nR({y6!' );
define( 'NONCE_SALT',       ',_H?iC)zm^n[s|(MYQ/AM2?}.Pfb/cxDs7|>V9.$r#6NJ|CX@Ld<a=1y 4.;gHd+' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
